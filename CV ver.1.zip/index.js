// SEND MESSAGE
document.addEventListener("DOMContentLoaded", function () {
    // Contact button event
    document.getElementById("contactButton").addEventListener("click", function () {
        window.location.href = "mailto:your.email@example.com";
    });

    // Smooth scrolling for navbar links
    document.querySelectorAll(".nav-link").forEach(link => {
        link.addEventListener("click", function (event) {
            event.preventDefault();
            const targetId = this.getAttribute("href").substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 60,
                    behavior: "smooth"
                });
            }
        });
    });
});

// Add event listener to toggle the navbar
document.addEventListener('DOMContentLoaded', function () {
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbar = document.querySelector('.navbar');

    // Toggle navbar open class
    navbarToggler.addEventListener('click', function () {
        navbar.classList.toggle('open');
    });
});


// Hoover function skills bars function
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".progress-fill").forEach((bar) => {
        bar.addEventListener("mouseenter", function () {
            this.style.backgroundColor = getRandomShade();
        });

        bar.addEventListener("mouseleave", function () {
            this.style.backgroundColor = "#080808"; // Reset to default
        });
    });

    function getRandomShade() {
        const shades = ["#91AC9A", "#A9C3B6", "#CEDFDF", "#B7D1D3", "#A6C3CE", "#8FB8CA"];
        return shades[Math.floor(Math.random() * shades.length)];
    }
});

// Hoover function hobby function
document.addEventListener("DOMContentLoaded", function () {
    const hobbyDescriptions = {
        "Play game": "I enjoy playing FPS, card, arcade, and puzzle games!",
        "Listen music": "I love rap, pop, lofi, sad, R&B, and hip-hop music!",
        "Reading comic": "Manga, manhwa, and comics are my favorite reads!",
        "Playing badminton": "A fun and active way to stay fit and competitive!",
        "Coding": "I enjoy solving problems and building web projects!"
    };

    document.querySelectorAll(".hobby-list li").forEach((item) => {
        item.addEventListener("mouseenter", function (event) {
            let popup = document.createElement("div");
            popup.className = "hobby-popup";
            popup.innerText = hobbyDescriptions[event.target.innerText] || "I love this hobby!";
            document.body.appendChild(popup);

            let rect = event.target.getBoundingClientRect();
            popup.style.left = `${rect.left + window.scrollX + rect.width / 2}px`;
            popup.style.top = `${rect.top + window.scrollY - 30}px`;

            setTimeout(() => {
                popup.style.opacity = "1";
                popup.style.transform = "translateY(-5px)";
            }, 10);

            event.target.addEventListener("mouseleave", function () {
                popup.style.opacity = "0";
                popup.style.transform = "translateY(0)";
                setTimeout(() => popup.remove(), 300);
            });
        });
    });
});
